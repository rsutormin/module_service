package us.kbase.jkidl;

public class JKidlTest {
	public static void main(String[] args) throws Exception {
		//SpecParser.main(new String[] {"src/us/kbase/scripts/tests/test10.spec.properties"});
		SpecParser.main(new String[] {"../WorkspaceDeluxe/workspace.spec"});
	}
}
